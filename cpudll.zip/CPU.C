// Includes
#include <windows.h>
#include <intrinsics.h>
#include <stdio.h>

BOOL WINAPI LibMain(HINSTANCE hDLLInst, DWORD fdwReason, LPVOID lpvReserved)
{
    switch (fdwReason)
    {
        case DLL_PROCESS_ATTACH:

            break;
        case DLL_PROCESS_DETACH:

            break;
        case DLL_THREAD_ATTACH:

            break;
        case DLL_THREAD_DETACH:

            break;
    }
    return TRUE;
}


//Prototypes

long long _cpuid(_CPUID *);
int _cpuidPresent(void);


//Functions

__declspec(dllexport) int cpuid_avail(void)
{
	return _cpuidPresent();
}

__declspec(dllexport) double cycles_elapsed(void)
{
	return _rdtsc();
}


static _CPUID id;

__declspec(dllexport) void cpu_id(void)
{
	_cpuid(&id);
}

__declspec(dllexport) int cpuid_Stepping(void){
	return id.Stepping;}

__declspec(dllexport) int cpuid_Model(void){
	return id.Model;}

__declspec(dllexport) int cpuid_Family(void){
	return id.Family;}

__declspec(dllexport) int cpuid_Type(void){
	return id.Type;}

__declspec(dllexport) int cpuid_FpuPresent(void){
	return id.FpuPresent;}

__declspec(dllexport) int cpuid_VME(void){
	return id.VME;}

__declspec(dllexport) int cpuid_DebuggingExtensions(void){
	return id.DebuggingExtensions;}

__declspec(dllexport) int cpuid_PageSizeExtensions(void){
	return id.PageSizeExtensions;}

__declspec(dllexport) int cpuid_TimeStampCounter(void){
	return id.TimeStampCounter;}

__declspec(dllexport) int cpuid_PhysicalAddressExtensions(void){
	return id.PhysicalAddressExtensions;}

__declspec(dllexport) int cpuid_MachineCheckException(void){
	return id.MachineCheckException;}

__declspec(dllexport) int cpuid_CMPXCHG8B(void){
	return id.CMPXCHG8B;}

__declspec(dllexport) int cpuid_APICOnChip(void){
	return id.APICOnChip;}

__declspec(dllexport) int cpuid_SEP(void){
	return id.SEP;}

__declspec(dllexport) int cpuid_MTRR(void){
	return id.MTRR;}

__declspec(dllexport) int cpuid_PGE(void){
	return id.PGE;}

__declspec(dllexport) int cpuid_MCA(void){
	return id.MCA;}

__declspec(dllexport) int cpuid_CMOV(void){
	return id.CMOV;}

__declspec(dllexport) int cpuid_FGPAT(void){
	return id.FGPAT;}

__declspec(dllexport) int cpuid_PSE36(void){
	return id.PSE36;}

__declspec(dllexport) int cpuid_PN(void){
	return id.PN;}

__declspec(dllexport) int cpuid_MMX(void){
	return id.MMX;}

__declspec(dllexport) int cpuid_FXSR(void){
	return id.FXSR;}

__declspec(dllexport) int cpuid_XMM(void){
	return id.XMM;}

__declspec(dllexport) long cpuid_Reserved1(void){
	return id.Reserved1;}

__declspec(dllexport) int cpuid_reserved2(void){
	return id.reserved2;}

__declspec(dllexport) int cpuid_reserved3(void){
	return id.reserved3;}

__declspec(dllexport) int cpuid_reserved4(void){
	return id.reserved4;}
