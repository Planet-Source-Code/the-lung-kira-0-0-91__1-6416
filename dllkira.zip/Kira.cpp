//The functions that are not mine are clearly labeled im not a c/c++/asm master so I just used premade functions

#include <windows.h>
#include <winuser.h>

#define Dll _stdcall


/*bool cpuid_avail(void) // Not mine
{
	unsigned long int Avail;

	Avail = 0l;					    //preset to NO CPUID available status

	__asm
	{
		push ebx					//save since we use it
		pushfd						//get eflags ...
		pop eax						
		mov ebx,eax					//store current eflags
		xor eax,0x00200000			//flip bit 23
		push eax					//attempt to write it back
		popfd						
		pushfd						
		pop eax						
		xor eax,ebx					//if not flippable, eax is zeroed
		je cq_endex					
		mov Avail,0x00000001	    //indicate CPUID is available
	cq_endex:
		push ebx					
		popfd						//restore eflags to what it was on entry
		pop ebx						//restore ebx to what it was on entry
	}

	return (Avail==1);
}

void Dll cycles_elapsed (__int64* cycles) // Not mine
{
	__asm 
	{
		cpuid				//a serializing instruction
		cpuid				//recommended to do it 3 times
		cpuid

		rdtsc				//read timer stamp counter
		mov edi, cycles		//low order 32bits
		mov [edi  ], eax
		mov [edi+4], edx
	}
}

// Not mine
void Dll Cpuid(const unsigned long func,
			unsigned long *r_eax, unsigned long *r_ebx,
			unsigned long *r_ecx, unsigned long *r_edx)
{
	__asm
		{
			pushad				;	// save all registers
			;						//
			mov eax,func		;	// call CPUID with the supplied input value
			_emit 0x0f			;	//
			_emit 0xa2			;	//
			;						//
			mov edi,[ebp+12]	;	// if r_eax is not NULL, return the value
			cmp edi,0			;	// of eax
			jz ck_bx			;
			mov [edi],eax		;
		ck_bx:
			mov edi,[ebp+16]	;	// if r_ebx is not NULL, return the value
			cmp edi,0			;	// of ebx
			jz ck_cx			;
			mov [edi],ebx		;
		ck_cx:
			mov edi,[ebp+20]	;	// ... and likewise for ecx ...
			cmp edi,0			;
			jz ck_dx			;
			mov [edi],ecx		;
		ck_dx:
			mov edi,[ebp+24]	;	// ... and likewise for edx ...
			cmp edi,0			;
			jz ck_end			;
			mov [edi],edx		;
		ck_end:
			popad;					// restore everything to entry status
		}
}

void Dll Cpuid(const unsigned long func,
			unsigned long *r_eax, unsigned long *r_ebx,
			unsigned long *r_ecx, unsigned long *r_edx)
{
	_asm
	{
		mov		eax,func

		_emit	0x0f
		_emit	0xa2

		mov		r_eax,eax
		mov		r_ebx,ebx
		mov		r_ecx,ecx
		mov		r_edx,edx
	}
}*/

//Global Mouse Hook

//If these values are shared it only picks up messages like a app hook not a global
#pragma data_seg(".SHARDAT")
HWND	m_hHwnd = 0;
HHOOK	m_hHook = NULL;
#pragma data_seg()

void WINAPI HookCallbackInit(HWND objHWND, HHOOK hkHWND)
{
	m_hHwnd = objHWND;	//Object hwnd
	m_hHook = hkHWND;	//Hook hwnd
}

LRESULT CALLBACK MouseHookProc( int nCode, WPARAM wParam, LPARAM lParam)
{	
	if (nCode < 0) 
	{
		//Dont break the chain
		return CallNextHookEx(m_hHook, nCode, wParam, lParam);
	}

	if (nCode == HC_ACTION) 
	{
		if ((wParam >= 0xA0) & (wParam <= 0xA9)) //Didnt write this part
		{
			wParam = wParam + 352;
		}

		if (wParam == WM_MOUSEMOVE)
		{
		//I can not send asyncronus info to vb any other way
		PostMessage(m_hHwnd, wParam, 0, MAKEWPARAM(
			( (MOUSEHOOKSTRUCT*) lParam )->pt.x,
			( (MOUSEHOOKSTRUCT*) lParam )->pt.y));
		}
	}

	return 0;
}


//Spegetti code , cut n paste stuff here

BOOL WINAPI DllMain(HINSTANCE hinstDLL, DWORD fdwReason, LPVOID) {
	if (fdwReason == DLL_PROCESS_ATTACH) {
		DisableThreadLibraryCalls(hinstDLL);
	}
	return TRUE;
}

// This is to prevent the CRT from loading, thus making this a smaller and faster dll.
extern "C" BOOL __stdcall _DllMainCRTStartup( HINSTANCE hinstDLL, DWORD fdwReason, LPVOID lpvReserved) {
    return DllMain( hinstDLL, fdwReason, lpvReserved );
}